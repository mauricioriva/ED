
Mauricio Riva Palacio Orozco 316666343

Las funciones recursivas fueron lo más complicado de entender al igual que resolver los problemas de loki y mono.

En general la práctica estuvo muy bien y realmente aprendes a programar, lo mejor de la práctica es que debes investigar fórmulas para resolver el problema e ingresar esas formulas al código.


