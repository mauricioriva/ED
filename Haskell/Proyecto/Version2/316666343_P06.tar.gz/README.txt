
Practica 6 - Juego de Peliculas con emojis

Mauricio Riva Palacio Orozco 316666343
Jose Eliseo Ortiz Montaño 316184766
Derek Almanza Infante 316332022

Para compilar el programa abrir una terminal y ubicarse dentro de la carpeta 316666343_P06 y ejecutar los comandos siguientes:

]$ ghc Main.hs

]$ ./Main

Lo que pensamos para hacer la practica fue en dividir el juego en casos, tener varias funciones para que hiciera cada una una operación y la regresara o tuviera una accion sobre el programa, evitamos a toda costa tener todo el programa en solo 1 o 2 funciones. Las peliculas no salen tan aleatorias como queríamos debido a la funcion random predefinida por haskell no es tan aleatoria, pero es bastante funcional.

El programa ignora los espacios, los puntos y las mayúsculas para una mejor experiencia con el usuario.

Esta práctica fue bastante creativa además de entretenida y con un uso muy práctico :D.
